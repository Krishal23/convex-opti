% --- MA401 Lab Exam: Question 1 ---
clear; clc;

% Define objective function, gradient, and Hessian
f = @(x) (x(1) - 4)^4 + (x(2) - 3)^2 + 4*(x(3) + 5)^4;
grad_f = @(x) [4*(x(1) - 4)^3; 2*(x(2) - 3); 16*(x(3) + 5)^3];
hess_f = @(x) [12*(x(1) - 4)^2, 0, 0; 0, 2, 0; 0, 0, 48*(x(3) + 5)^2];

x0 = [0; 0; 0];
tol = 1e-9;
max_iter = 1000; % Safety limit

fprintf('--- Solving Question 1 (Tolerance: 1e-9) ---\n\n');

%% Method 1: Steepest Descent with Exact Line Search
x = x0; iter_sd = 0;
while norm(grad_f(x)) >= tol && iter_sd < max_iter
    g = grad_f(x);
    d = -g;
    % Exact line search using fminsearch
    alpha = fminsearch(@(a) f(x + a*d), 0);
    x = x + alpha * d;
    iter_sd = iter_sd + 1;
end
sol_sd = x;
fprintf('1. Steepest Descent:\n   Iterations: %d\n   Solution: [%.4f, %.4f, %.4f]\n\n', iter_sd, sol_sd(1), sol_sd(2), sol_sd(3));

%% Method 2: Newton's Method with Exact Line Search
x = x0; iter_nt = 0;
while norm(grad_f(x)) >= tol && iter_nt < max_iter
    g = grad_f(x);
    H = hess_f(x);
    d = -H \ g; % Newton direction
    
    alpha = fminsearch(@(a) f(x + a*d), 0);
    x = x + alpha * d;
    iter_nt = iter_nt + 1;
end
sol_nt = x;
fprintf('2. Newton''s Method:\n   Iterations: %d\n   Solution: [%.4f, %.4f, %.4f]\n\n', iter_nt, sol_nt(1), sol_nt(2), sol_nt(3));

%% Method 3: DFP Method with Exact Line Search
x = x0; iter_dfp = 0;
H_dfp = eye(3); % Initial inverse Hessian approximation H0 = I3
g = grad_f(x);

while norm(g) >= tol && iter_dfp < max_iter
    d = -H_dfp * g;
    alpha = fminsearch(@(a) f(x + a*d), 0);
    
    x_new = x + alpha * d;
    g_new = grad_f(x_new);
    
    del_x = x_new - x;
    del_g = g_new - g;
    
    % DFP Update Formula
    term1 = (del_x * del_x') / (del_x' * del_g);
    term2 = (H_dfp * del_g * del_g' * H_dfp) / (del_g' * H_dfp * del_g);
    H_dfp = H_dfp + term1 - term2;
    
    x = x_new;
    g = g_new;
    iter_dfp = iter_dfp + 1;
end
sol_dfp = x;
fprintf('3. DFP Method:\n   Iterations: %d\n   Solution: [%.4f, %.4f, %.4f]\n\n', iter_dfp, sol_dfp(1), sol_dfp(2), sol_dfp(3));