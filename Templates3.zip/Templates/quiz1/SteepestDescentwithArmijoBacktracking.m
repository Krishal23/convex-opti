% --- MA401 Lab Exam: Question 2 ---
clear; clc;

f = @(x) (x(1) - 4)^4 + (x(2) - 3)^2 + 4*(x(3) + 5)^4;
grad_f = @(x) [4*(x(1) - 4)^3; 2*(x(2) - 3); 16*(x(3) + 5)^3];

x0 = [0; 2; -1];
tol = 1e-6;
max_iter = 5000; % SD with Armijo can be slow, increase limit

% Armijo parameters
c = 1e-4; 
rho = 0.5;

x = x0; iter = 0;
fprintf('--- Solving Question 2 (Armijo Backtracking) ---\n');

while norm(grad_f(x)) >= tol && iter < max_iter
    g = grad_f(x);
    d = -g;
    
    % Armijo Backtracking Line Search
    alpha = 1; % Start with step size 1
    while f(x + alpha * d) > f(x) + c * alpha * (g' * d)
        alpha = rho * alpha;
    end
    
    x = x + alpha * d;
    iter = iter + 1;
end

fprintf('Total Iterations: %d\n', iter);
fprintf('Approximate Minimizer: [%.6f, %.6f, %.6f]\n\n', x(1), x(2), x(3));