% --- MA401 Lab Exam: Question 3 ---
clear; clc;

% Define the Q matrix and b vector from the problem statement
Q = [4, 1, 0, 2;
     1, 3, 1, 0;
     0, 1, 5, 1;
     2, 0, 1, 6];
b = [1; 2; 3; 4];

% Define the objective function and gradient using Q and b
f = @(x) 0.5 * x' * Q * x - x' * b;
grad_f = @(x) Q * x - b;

x = [0; 0; 0; 0];
tol = 1e-6;
max_iter = length(b) + 2; % CG should converge in n steps theoretically

fprintf('--- Solving Question 3 (Conjugate Gradient) ---\n');

g = grad_f(x);
d = -g;
iter = 0;

while norm(g) >= tol && iter < max_iter
    % Exact line search formula for quadratic functions
    alpha = (g' * g) / (d' * Q * d);
    
    x_new = x + alpha * d;
    g_new = grad_f(x_new);
    
    % Fletcher-Reeves beta update
    beta = (g_new' * g_new) / (g' * g);
    
    % Update direction
    d = -g_new + beta * d;
    
    x = x_new;
    g = g_new;
    iter = iter + 1;
end

final_f_val = f(x);

% Compare with exact linear system solution
x_exact = Q \ b;

fprintf('CG Iterations to converge: %d\n', iter);
fprintf('Final Function Value f(x): %.6f\n', final_f_val);

fprintf('\nComparison:\n');
fprintf('%-20s %-20s\n', 'CG Solution', 'Exact (Q\\b) Solution');
fprintf('----------------------------------------\n');
for i = 1:length(x)
    fprintf('%-20.6f %-20.6f\n', x(i), x_exact(i));
end