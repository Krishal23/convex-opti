% These methods are used to find the minimum of a single-variable function $f(\alpha)$ over a known interval $[a, b]$.
% Uses the golden ratio to narrow down the interval without needing derivatives.

function [alpha_opt, f_opt] = golden_section(f, a, b, tol)
    % f: function handle of one variable (e.g., @(x) x^2 - 4*x + 4)
    % a, b: initial bracket [a, b] containing the minimum
    % tol: tolerance for stopping criterion
    
    phi = (sqrt(5) - 1) / 2; % Golden ratio conjugate (~0.618)
    
    % Initial interior points
    x1 = b - phi * (b - a);
    x2 = a + phi * (b - a);
    
    f1 = f(x1);
    f2 = f(x2);
    
    iter = 0;
    while abs(b - a) > tol
        if f1 < f2
            b = x2;
            x2 = x1;
            f2 = f1;
            x1 = b - phi * (b - a);
            f1 = f(x1);
        else
            a = x1;
            x1 = x2;
            f1 = f2;
            x2 = a + phi * (b - a);
            f2 = f(x2);
        end
        iter = iter + 1;
    end
    
    alpha_opt = (a + b) / 2;
    f_opt = f(alpha_opt);
    fprintf('Golden Section converged in %d iterations.\n', iter);
end