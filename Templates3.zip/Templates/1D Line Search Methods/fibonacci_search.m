% Similar to Golden Section, but uses a pre-calculated number of iterations based on the Fibonacci sequence to achieve the desired tolerance.

function [alpha_opt, f_opt] = fibonacci_search(f, a, b, tol)
    % Calculate required number of iterations 'n'
    % Fn > (b-a)/tol
    target = (b - a) / tol;
    F = [1, 1];
    n = 2;
    while F(end) < target
        F(end+1) = F(end) + F(end-1);
        n = n + 1;
    end
    n = n - 1; % Total function evaluations
    
    x1 = a + (F(n-2) / F(n)) * (b - a);
    x2 = a + (F(n-1) / F(n)) * (b - a);
    
    f1 = f(x1);
    f2 = f(x2);
    
    for k = 1:(n-2)
        if f1 < f2
            b = x2;
            x2 = x1;
            f2 = f1;
            x1 = a + (F(n-k-2) / F(n-k)) * (b - a);
            f1 = f(x1);
        else
            a = x1;
            x1 = x2;
            f1 = f2;
            x2 = a + (F(n-k-1) / F(n-k)) * (b - a);
            f2 = f(x2);
        end
    end
    
    alpha_opt = (a + b) / 2;
    f_opt = f(alpha_opt);
    fprintf('Fibonacci Search completed %d iterations.\n', n-2);
end