% Used to find where the derivative f'(alpha) = 0.
function [alpha_opt] = bisection_method(df, a, b, tol)
    % df: function handle for the FIRST DERIVATIVE of f
    % Note: Requires df(a) and df(b) to have opposite signs
    
    if df(a) * df(b) >= 0
        error('Derivative must have opposite signs at a and b.');
    end
    
    iter = 0;
    while (b - a) / 2 > tol
        c = (a + b) / 2;
        if df(c) == 0
            break; % Exact root found
        elseif df(a) * df(c) < 0
            b = c;
        else
            a = c;
        end
        iter = iter + 1;
    end
    
    alpha_opt = (a + b) / 2;
    fprintf('Bisection converged in %d iterations.\n', iter);
end