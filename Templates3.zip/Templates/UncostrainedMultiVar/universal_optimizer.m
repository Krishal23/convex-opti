%This single function acts as a master framework. By changing the method string, it dynamically switches between Steepest Descent, Conjugate Gradient, Newton, and BFGS Quasi-Newton. It utilizes an Armijo backtracking line search for robust convergence.
function [x_opt, f_hist] = universal_optimizer(f, grad_f, hess_f, x0, method, tol, max_iter)
    % Inputs:
    % f, grad_f: Function handles for objective and gradient
    % hess_f: Function handle for Hessian (Only needed for 'Newton')
    % x0: Initial guess column vector
    % method: 'Steepest', 'CG', 'Newton', or 'BFGS'
    
    x = x0;
    g = grad_f(x);
    f_hist = zeros(max_iter, 1);
    
    % Initialize specifics for CG and BFGS
    d = -g; 
    H_bfgs = eye(length(x0)); % Initial inverse Hessian approx for BFGS
    
    for k = 1:max_iter
        f_hist(k) = f(x);
        
        if norm(g) < tol
            fprintf('%s converged at iteration %d\n', method, k);
            f_hist = f_hist(1:k);
            break;
        end
        
        % --- 1. DETERMINE DIRECTION (d) ---
        switch method
            case 'Steepest'
                d = -g;
                
            case 'Newton'
                H = hess_f(x);
                d = -H \ g; 
                
            case 'CG'
                if k == 1
                    d = -g;
                end
                % Beta update occurs at the end of the loop
                
            case 'BFGS'
                d = -H_bfgs * g;
                
            otherwise
                error('Unknown method.');
        end
        
        % --- 2. LINE SEARCH (Armijo Backtracking) ---
        alpha = 1; c1 = 1e-4; rho = 0.5;
        while f(x + alpha * d) > f(x) + c1 * alpha * (g' * d)
            alpha = rho * alpha;
            if alpha < 1e-10, break; end
        end
        
        % --- 3. UPDATE ---
        x_new = x + alpha * d;
        g_new = grad_f(x_new);
        
        % --- 4. POST-UPDATE CALCULATIONS (CG & BFGS) ---
        if strcmp(method, 'CG')
            % Fletcher-Reeves update
            beta = (g_new' * g_new) / (g' * g);
            d = -g_new + beta * d;
        end
        
        if strcmp(method, 'BFGS')
            s = x_new - x;
            y = g_new - g;
            rho_bfgs = 1 / (y' * s);
            I = eye(length(x));
            % BFGS Inverse Hessian Update
            H_bfgs = (I - rho_bfgs * s * y') * H_bfgs * (I - rho_bfgs * y * s') + rho_bfgs * (s * s');
        end
        
        % Step forward
        x = x_new;
        g = g_new;
    end
    x_opt = x;
end