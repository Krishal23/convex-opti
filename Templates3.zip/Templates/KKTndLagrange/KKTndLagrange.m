%Analytical constrained problems (Lagrange for equality, KKT for inequality) are best solved using MATLAB's symbolic math engine. This template sets up the exact systems of equations for any combination of constraints.

% --- UNIVERSAL KKT & LAGRANGE SOLVER SCRIPT ---
clear; clc;

% 1. Define Variables
syms x1 x2 lambda1 mu1 % Add more x, lambda, mu as needed for dimension
vars = [x1; x2];

% 2. Define Objective Function
f = x1^2 + x2^2; 

% 3. Define Equality Constraints: h(x) = 0 (Leave empty [] if none)
% e.g., h = [x1 + x2 - 4];
h = []; 
lambdas = [lambda1]; % Ensure dimensions match h

% 4. Define Inequality Constraints: g(x) <= 0 (Leave empty [] if none)
% e.g., g = [2 - x1 - x2];  % Convert x1+x2 >= 2 to 2-x1-x2 <= 0
g = [2 - x1 - x2]; 
mus = [mu1]; % Ensure dimensions match g

% --- SYSTEM SETUP ---
% Build Lagrangian: L = f + lambda^T * h + mu^T * g
L = f;
if ~isempty(h), L = L + lambdas * h; end
if ~isempty(g), L = L + mus * g; end

% Gradient of L with respect to x = 0
grad_L_x = gradient(L, vars) == 0;

% Initialize equation system
eqns = grad_L_x;

% Add Equality Constraints
if ~isempty(h)
    eqns = [eqns; h == 0];
end

% Add Complementary Slackness (mu_i * g_i = 0)
if ~isempty(g)
    for i = 1:length(g)
        eqns = [eqns; mus(i) * g(i) == 0];
    end
end

% --- SOLVE THE SYSTEM ---
% Collect all variables to solve for
all_vars = vars;
if ~isempty(h), all_vars = [all_vars; lambdas']; end
if ~isempty(g), all_vars = [all_vars; mus']; end

% Solve using vpasolve or solve
sol = solve(eqns, all_vars, 'Real', true);

% --- FILTER KKT CONDITIONS ---
fprintf('--- Candidate Solutions ---\n');
num_sols = length(sol.(char(vars(1))));

for i = 1:num_sols
    valid = true;
    
    % Extract point
    pt_x = zeros(length(vars), 1);
    for v = 1:length(vars)
        pt_x(v) = double(sol.(char(vars(v)))(i));
    end
    
    % Check Primal Feasibility: g(x) <= 0
    if ~isempty(g)
        g_val = double(subs(g, vars, pt_x));
        if any(g_val > 1e-6) % Tolerance for floating point
            valid = false;
        end
    end
    
    % Check Dual Feasibility: mu >= 0
    if ~isempty(g)
        for m = 1:length(mus)
            mu_val = double(sol.(char(mus(m)))(i));
            if mu_val < -1e-6
                valid = false;
            end
        end
    end
    
    if valid
        fprintf('Valid KKT Point found:\n');
        disp('x = '); disp(pt_x');
        obj_val = double(subs(f, vars, pt_x));
        fprintf('Objective Value f(x) = %.4f\n\n', obj_val);
    end
end