% =========================================================================
% QUESTION 3: Steepest Descent with Secant Line Search
% =========================================================================
clear; clc;

% Define symbolic variables
syms x1 x2 x3
vars = [x1; x2; x3];

% Define the objective function
f_sym = (x1 - 4)^4 + (x2 - 3)^2 + 4*(x3 + 5)^4;

% Create function handles for fast numeric evaluation (faster than subs)
grad_sym = gradient(f_sym, vars);
f_func = matlabFunction(f_sym, 'Vars', {vars});
grad_func = matlabFunction(grad_sym, 'Vars', {vars});

% Parameters
x_k = [0; 0; 0]; % Initial guess (assumed as it was omitted in prompt text)
epsilon_grad = 1e-6;
epsilon_ls = 1e-4;
max_iter = 1000;
alpha_init = [0, 0.001]; % Initial conditions for secant method

k = 0;
fprintf('--- Running Steepest Descent with Secant Line Search ---\n');

while k < max_iter
    % Evaluate current gradient
    g_k = grad_func(x_k);
    
    % Stopping Criterion
    if norm(g_k) <= epsilon_grad
        break;
    end
    
    % Steepest Descent Direction
    d_k = -g_k;
    
    % Perform Secant Line Search to find step size
    alpha_k = secant_line_search(f_func, grad_func, epsilon_ls, x_k, alpha_init, d_k);
    
    % Update position
    x_k = x_k + alpha_k * d_k;
    k = k + 1;
end

% Final evaluations
optimal_f = f_func(x_k);

fprintf('Optimal Solution:\n');
disp(x_k);
fprintf('Iterations required: %d\n', k);
fprintf('Objective Function at optimal solution: %.8f\n\n', optimal_f);


% =========================================================================
% LOCAL FUNCTION DEFINITION
% =========================================================================
function alpha = secant_line_search(f, grad_f, epsilon_ls, x, alpha_init, d)
    % Initialize previous and current alpha guesses
    a_prev = alpha_init(1);
    a_curr = alpha_init(2);
    
    % Derivative of phi(alpha) = f(x + alpha*d) with respect to alpha
    % phi'(alpha) = d^T * grad_f(x + alpha * d)
    
    % Evaluate phi'(0) for the stopping criteria
    phi_prime_0 = d' * grad_f(x);
    
    % Evaluate at initial guesses
    p_prev = d' * grad_f(x + a_prev * d);
    p_curr = d' * grad_f(x + a_curr * d);
    
    % Stopping criteria: |d^T * grad_f(x + a*d)| <= epsilon_ls * |d^T * grad_f(x)|
    while abs(p_curr) > epsilon_ls * abs(phi_prime_0)
        
        % Prevent division by zero if gradient hasn't changed
        if (p_curr - p_prev) == 0
            break;
        end
        
        % Secant formula update
        a_next = a_curr - p_curr * ((a_curr - a_prev) / (p_curr - p_prev));
        
        % Step forward
        a_prev = a_curr;
        p_prev = p_curr;
        
        a_curr = a_next;
        p_curr = d' * grad_f(x + a_curr * d);
    end
    
    alpha = a_curr;
end