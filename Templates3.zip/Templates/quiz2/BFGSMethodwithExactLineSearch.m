% =========================================================================
% QUESTION 2: BFGS Method Implementation
% =========================================================================
clear; clc;

% Define symbolic variables
syms x1 x2

% Define the quadratic objective function
f_sym = 2.5*x1^2 - 3*x1*x2 + x2^2 - x2 + log(pi);

% Initial conditions and tolerance
x0 = [0; 0];
epsilon = 1e-6;

% Call the BFGS method function
fprintf('--- Running BFGS Method ---\n');
[x_opt, k] = bfgs_method(f_sym, x0, epsilon);

% Display results
fprintf('Optimal Solution:\n');
disp(double(x_opt));
fprintf('Number of iterations: %d\n\n', k);


% =========================================================================
% LOCAL FUNCTION DEFINITION
% =========================================================================
function [x_opt, k] = bfgs_method(f, x0, epsilon)
    % Extract symbolic variables
    vars = symvar(f);
    
    % Calculate gradient and Hessian
    grad_sym = gradient(f, vars);
    
    % For a quadratic problem, the Hessian is the constant matrix 'Q'
    Q = double(hessian(f, vars)); 
    
    % Initialize variables
    x_k = x0(:);
    n = length(x_k);
    H_inv = eye(n); % Initial Inverse Hessian approximation is Identity matrix
    k = 0;
    
    % Initial gradient evaluation
    g_k = double(subs(grad_sym, vars, x_k'));
    
    while norm(g_k) >= epsilon
        % 1. Search Direction
        d_k = -H_inv * g_k;
        
        % 2. Exact Line Search for Quadratic Problem
        % alpha = - (g^T * d) / (d^T * Q * d)
        alpha_k = -(g_k' * d_k) / (d_k' * Q * d_k);
        
        % 3. Update position
        x_next = x_k + alpha_k * d_k;
        
        % 4. Evaluate new gradient
        g_next = double(subs(grad_sym, vars, x_next'));
        
        % 5. BFGS Inverse Hessian Update
        s_k = x_next - x_k;
        y_k = g_next - g_k;
        
        rho_k = 1 / (y_k' * s_k);
        I = eye(n);
        
        % Update formula
        H_inv = (I - rho_k * s_k * y_k') * H_inv * (I - rho_k * y_k * s_k') + rho_k * (s_k * s_k');
        
        % Step forward
        x_k = x_next;
        g_k = g_next;
        k = k + 1;
        
        % Safety break
        if k > 1000
            disp('Maximum iterations reached.');
            break;
        end
    end
    
    x_opt = x_k;
end