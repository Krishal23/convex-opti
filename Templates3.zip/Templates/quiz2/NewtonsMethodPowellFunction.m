% =========================================================================
% QUESTION 1: Newton's Method Implementation
% =========================================================================
clear; clc;

% Define symbolic variables
syms x1 x2 x3 x4

% Define the objective function (Powell's Function)
f_sym = (x1 + 10*x2)^2 + 5*(x3 - x4)^2 + (x2 - 2*x3)^4 + 10*(x1 - x4)^4;

% Initial conditions and tolerance
x0 = [3; -1; 0; 1];
epsilon = 1e-6;

% Call the Newton method function
fprintf('--- Running Newton''s Method ---\n');
[x_opt, k] = Newton_method(f_sym, x0, epsilon);

% Display results
fprintf('Optimal Solution:\n');
disp(double(x_opt));
fprintf('Number of iterations: %d\n\n', k);


% =========================================================================
% LOCAL FUNCTION DEFINITION
% =========================================================================
function [x_opt, k] = Newton_method(f, x0, epsilon)
    % Extract symbolic variables from the function automatically
    vars = symvar(f); 
    
    % Use inbuilt functions to calculate symbolic Gradient and Hessian
    grad_sym = gradient(f, vars);
    hess_sym = hessian(f, vars);
    
    % Initialize variables
    x_k = x0(:); % Ensure it's a column vector
    k = 0;
    
    while true
        % Evaluate gradient at current point
        g_k = double(subs(grad_sym, vars, x_k'));
        
        % Stopping criterion: || grad f(x_k) || < epsilon
        if norm(g_k) < epsilon
            break;
        end
        
        % Evaluate Hessian at current point
        H_k = double(subs(hess_sym, vars, x_k'));
        
        % Calculate Newton direction: d_k = -H_k^(-1) * g_k
        % We use mldivide (\) for numerical stability instead of inv()
        d_k = -H_k \ g_k;
        
        % Update rule
        x_k = x_k + d_k;
        k = k + 1;
        
        % Safety break for divergence
        if k > 1000
            disp('Maximum iterations reached without convergence.');
            break;
        end
    end
    
    x_opt = x_k;
end