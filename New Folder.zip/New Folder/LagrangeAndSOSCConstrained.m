% Topic 5: Lagrange Multipliers and SOSC
syms x1 x2 lambda
vars = [x1; x2];

% Objective function f(x) = (x1-1)^2 + (x2-3)^2
f = (x1 - 1)^2 + (x2 - 3)^2;
% Constraint function h(x) = x1^2 + x2^2 - 9 = 0
h = x1^2 + x2^2 - 9;

% Lagrangian L(x, lambda) = f(x) + lambda * h(x)
L = f + lambda * h;

% First order conditions
grad_L_x = gradient(L, vars);
eqns = [grad_L_x == 0; h == 0];

% Solve for x1, x2, lambda
[sol_x1, sol_x2, sol_lambda] = solve(eqns, [x1, x2, lambda], 'Real', true);

fprintf('--- Lagrange Multipliers ---\n');
% Calculate Hessian of L w.r.t x
H_L = hessian(L, vars);
grad_h = gradient(h, vars);

for i = 1:length(sol_x1)
    pt = [double(sol_x1(i)); double(sol_x2(i))];
    lam = double(sol_lambda(i));
    
    fprintf('\nPoint %d: x = [%.4f, %.4f]^T, lambda = %.4f\n', i, pt(1), pt(2), lam);
    
    % Evaluate Hessian and gradient of h at the point
    H_L_val = double(subs(H_L, [vars; lambda], [pt; lam]));
    grad_h_val = double(subs(grad_h, vars, pt));
    
    % Find null space basis of the constraint gradient
    Z = null(grad_h_val');
    
    % Projected Hessian
    Proj_Hessian = Z' * H_L_val * Z;
    
    fprintf('Projected Hessian = %.4f\n', Proj_Hessian);
    if Proj_Hessian > 0
        fprintf('SOSC Satisfied -> Strict Local Minimizer\n');
    elseif Proj_Hessian < 0
        fprintf('SOSC Fails -> Strict Local Maximizer\n');
    else
        fprintf('SOSC Inconclusive\n');
    end
end