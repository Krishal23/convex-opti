% --- DFP Method ---

Q = [5, -3; 
    -3,  2];
b = [0; 1];

x = [0; 0];
H = eye(2);
g = Q * x - b;

fprintf('\n--- DFP Method ---\n');
for k = 1:5 % Generally converges in n steps for nxn matrix
    fprintf('Iter %d: x = [%.4f; %.4f]\n', k-1, x(1), x(2));
    
    if norm(g) < 1e-6
        break;
    end
    
    % Direction
    d = -H * g;
    
    % Exact line search
    alpha = -(g' * d) / (d' * Q * d);
    
    % Updates
    x_new = x + alpha * d;
    g_new = Q * x_new - b;
    
    delta_x = x_new - x;      % delta_x^(k) = alpha_k * d^(k)
    delta_g = g_new - g;      % delta_g^(k)
    
    % DFP Update Formula
    term1 = (delta_x * delta_x') / (delta_x' * delta_g);
    term2 = (H * delta_g * delta_g' * H) / (delta_g' * H * delta_g);
    H = H + term1 - term2;
    
    x = x_new;
    g = g_new;
end
disp('Final H (DFP):');
disp(H);