% --- Quasi-Newton: Rank One Algorithm (ROA) ---

% Define the quadratic function components
% f(x) = 0.5 * x^T * Q * x + c, where Q = [2, 0; 0, 1]
Q = [2, 0; 
     0, 1];
b = [0; 0]; % No linear term

% Initializations
x = [1; 2];       % x^(0)
H = eye(2);       % H_0 = I_2
g = Q * x - b;    % Initial gradient g^(0)

fprintf('--- Rank One Algorithm (ROA) ---\n');
fprintf('Iter 0: x = [%.4f; %.4f], norm(g) = %.6f\n', x(1), x(2), norm(g));

max_iter = 10;
tol = 1e-6;

for k = 1:max_iter
    if norm(g) < tol
        fprintf('Converged at iteration %d\n', k-1);
        break;
    end
    
    % Step 1: Calculate direction d^(k) = -H_k * g^(k)
    d = -H * g;
    
    % Step 2: Exact line search for quadratic function
    % alpha_k = argmin f(x + alpha*d)
    alpha = -(g' * d) / (d' * Q * d);
    
    % Step 3: Update x
    x_new = x + alpha * d;
    
    % Calculate new gradient
    g_new = Q * x_new - b;
    
    % Step 4: Calculate differences
    delta_x = x_new - x;
    delta_g = g_new - g;
    
    % Step 5: Rank One Update for H
    % Denominator term: (delta_g)^T * (delta_x - H * delta_g)
    term = delta_x - H * delta_g;
    denominator = delta_g' * term;
    
    % Safety check to avoid division by zero (a known issue with ROA)
    if abs(denominator) < 1e-8
        disp('Denominator too small, terminating update to prevent instability.');
        break;
    end
    
    H = H + (term * term') / denominator;
    
    % Prepare for next iteration
    x = x_new;
    g = g_new;
    
    fprintf('Iter %d: x = [%.4f; %.4f], norm(g) = %.6f\n', k, x(1), x(2), norm(g));
end

disp('Final estimated inverse Hessian (H):');
disp(H);
disp('Exact inverse Hessian (inv(Q)):');
disp(inv(Q));