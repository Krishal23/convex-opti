syms x1 x2 lambda
vars = [x1; x2];

% Objective and Constraint
f = 2*x1 + 3*x2 - 4;
h = x1*x2 - 6;

% Lagrangian: L = f + lambda * h
L = f + lambda * h;

% First Order Conditions (Gradient of L w.r.t x1, x2, lambda)
grad_L_x = gradient(L, vars);
grad_L_lambda = h; % derivative w.r.t lambda is just the constraint
eqns = [grad_L_x == 0; grad_L_lambda == 0];

% Solve for critical points
[x1_sol, x2_sol, lambda_sol] = solve(eqns, [x1, x2, lambda]);

fprintf('--- Critical Points --- \n');
for i = 1:length(x1_sol)
    fprintf('Point %d: x1 = %s, x2 = %s, lambda = %s\n', ...
        i, char(x1_sol(i)), char(x2_sol(i)), char(lambda_sol(i)));
end

% Second Order Sufficient Condition (SOSC)
% Compute the Hessian of the Lagrangian w.r.t x
H_L = hessian(L, vars);

% Gradient of constraint h
grad_h = gradient(h, vars);

fprintf('\n--- SOSC Check --- \n');
for i = 1:length(x1_sol)
    pt = [x1_sol(i); x2_sol(i)];
    lam = lambda_sol(i);
    
    H_L_val = double(subs(H_L, [vars; lambda], [pt; lam]));
    grad_h_val = double(subs(grad_h, vars, pt));
    
    % For SOSC, we check if y^T * H_L * y > 0 for all y in Null(grad_h^T)
    % Find a basis for the null space of the constraint gradient
    Z = null(grad_h_val'); 
    
    % Projected Hessian
    Proj_Hessian = Z' * H_L_val * Z;
    
    fprintf('At Point %d: Projected Hessian = %.4f\n', i, Proj_Hessian);
    if Proj_Hessian > 0
        fprintf('SOSC satisfied: Strict Local Minimizer.\n');
    elseif Proj_Hessian < 0
        fprintf('Strict Local Maximizer.\n');
    else
        fprintf('Inconclusive by SOSC.\n');
    end
end