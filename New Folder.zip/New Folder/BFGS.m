% --- BFGS Method ---

Q = [5, -3; 
    -3,  2];
b = [0; 1];

x = [0; 0];
H = eye(2);
g = Q * x - b;

fprintf('\n--- BFGS Method ---\n');
for k = 1:5
    fprintf('Iter %d: x = [%.4f; %.4f]\n', k-1, x(1), x(2));
    
    if norm(g) < 1e-6
        break;
    end
    
    % Direction
    d = -H * g;
    
    % Exact line search
    alpha = -(g' * d) / (d' * Q * d);
    
    % Updates
    x_new = x + alpha * d;
    g_new = Q * x_new - b;
    
    delta_x = x_new - x;
    delta_g = g_new - g;
    
    % BFGS Update Formula (for inverse Hessian H)
    rho = 1 / (delta_g' * delta_x);
    I = eye(2);
    
    % H_{k+1} = (I - rho * delta_x * delta_g^T) * H_k * (I - rho * delta_g * delta_x^T) 
    %           + rho * delta_x * delta_x^T
    term1 = I - rho * delta_x * delta_g';
    term2 = I - rho * delta_g * delta_x';
    term3 = rho * (delta_x * delta_x');
    
    H = term1 * H * term2 + term3;
    
    x = x_new;
    g = g_new;
end
disp('Final H (BFGS):');
disp(H);
disp('Exact inverse Hessian (inv(Q)):');
disp(inv(Q));