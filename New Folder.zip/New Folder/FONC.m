syms x1 x2
f = x1^2 + 0.5*x2^2 + 3*x2 + 4.5;
vars = [x1; x2];
x_star = [1; 3];

% Calculate gradient at x_star
grad_f = gradient(f, vars);
grad_f_star = double(subs(grad_f, vars, x_star));

fprintf('Gradient at x* = [%.1f; %.1f]\n', grad_f_star(1), grad_f_star(2));

% Since x* = [1, 3] is in the strict interior of Omega (x1>0, x2>0), 
% any direction is feasible. For FONC to hold in the interior, 
% the gradient MUST be strictly zero.
if norm(grad_f_star) == 0
    fprintf('FONC is SATISFIED.\n');
else
    fprintf('FONC is NOT SATISFIED because gradient is non-zero in the interior.\n');
end