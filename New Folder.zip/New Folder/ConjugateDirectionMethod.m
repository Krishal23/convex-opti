% Topic 2: Conjugate Direction Method
Q = [4, 2; 
     2, 2];
b = [-1; 1];

x = [0; 0];
% Q-conjugate directions
d0 = [1; 0];
d1 = [-1; 2]; 
D = [d0, d1]; 

fprintf('--- Conjugate Direction Method ---\n');
for k = 1:2
    d = D(:, k);
    g = Q * x - b;
    
    % Alpha for exact line search
    alpha = -(g' * d) / (d' * Q * d);
    
    x = x + alpha * d;
    
    fprintf('Iteration %d: x = [%.4f, %.4f]\n', k, x(1), x(2));
end