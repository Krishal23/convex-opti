% Topic 4: Armijo Backtracking (Steepest Descent & Newton)
f = @(x) x^4 + x^2;
grad_f = @(x) 4*x^3 + 2*x;
hess_f = @(x) 12*x^2 + 2;

c1 = 0.2; % Sufficient decrease parameter (alpha on the board)
rho = 0.5; % Contraction factor (beta on the board)

%% Part a: Steepest Descent with Armijo
x_sd = 1.7;
fprintf('--- Steepest Descent + Armijo ---\n');
for i = 1:10
    d = -grad_f(x_sd);
    eta = 1; % Initial step size
    
    % Armijo condition: f(x + eta*d) <= f(x) + c1 * eta * grad(x)' * d
    while f(x_sd + eta*d) > f(x_sd) + c1 * eta * grad_f(x_sd) * d
        eta = rho * eta;
    end
    
    x_sd = x_sd + eta * d;
    fprintf('Iter %d: x = %.6f, f(x) = %.6f\n', i, x_sd, f(x_sd));
end

%% Part b: Newton's Method with Armijo
x_nt = 2.0;
fprintf('\n--- Newton Method + Armijo ---\n');
for i = 1:10
    g = grad_f(x_nt);
    H = hess_f(x_nt);
    
    if abs(g) < 1e-6
        fprintf('Converged!\n'); break;
    end
    
    d = -H \ g; % Newton direction
    eta = 1;
    
    % Armijo condition
    while f(x_nt + eta*d) > f(x_nt) + c1 * eta * g * d
        eta = rho * eta;
    end
    
    x_nt = x_nt + eta * d;
    fprintf('Iter %d: x = %.6f, f(x) = %.6f\n', i, x_nt, f(x_nt));
end