% MATLAB Code to check the first-order condition of convexity
syms x y
vars = [x; y];

% Define functions and point pairs {f, X, Y}
problems = {
    x^2 + y^3, [1; 1], [1; -1];
    x^4 + y^4, [1; 0], [0; 2];
    sin(x^2*y), [1; 2], [-1; -2];
    -exp(-x^2-y^2), [2; 1], [2; 1]
};

for i = 1:size(problems, 1)
    f = problems{i, 1};
    X_val = problems{i, 2};
    Y_val = problems{i, 3};
    
    % Compute Gradient
    grad_f = gradient(f, vars);
    
    % Evaluate f(X), f(Y), and grad_f(Y)
    f_X = double(subs(f, vars, X_val));
    f_Y = double(subs(f, vars, Y_val));
    grad_f_Y = double(subs(grad_f, vars, Y_val));
    
    % First Order Condition: f(X) >= f(Y) + grad_f(Y)' * (X - Y)
    RHS = f_Y + grad_f_Y' * (X_val - Y_val);
    
    fprintf('Problem (%c):\n', char(96+i));
    fprintf('LHS f(x) = %.4f, RHS = %.4f\n', f_X, RHS);
    if f_X >= RHS
        fprintf('Condition SATISFIED at these specific points.\n\n');
    else
        fprintf('Condition FAILED at these specific points (Not Convex).\n\n');
    end
end