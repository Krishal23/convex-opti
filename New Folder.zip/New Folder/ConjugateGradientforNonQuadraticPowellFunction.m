% Topic 3: Non-Linear CG (Powell Function) using Fletcher-Reeves
syms x1 x2 x3 x4 alpha_sym
vars = [x1; x2; x3; x4];

% Powell Function
f_sym = (x1 + 10*x2)^2 + 5*(x3 - x4)^2 + (x2 - 2*x3)^4 + 10*(x1 - x4)^4;
grad_sym = gradient(f_sym, vars);

% Convert symbolic to anonymous functions for speed
f = matlabFunction(f_sym, 'Vars', {vars});
grad = matlabFunction(grad_sym, 'Vars', {vars});

x = [3; -1; 0; 1];
g = grad(x);
d = -g;

fprintf('--- Non-Linear CG (Fletcher-Reeves) ---\n');
for k = 0:10 % Running for 10 iterations as an example
    if norm(g) < 1e-5
        break;
    end
    
    % Exact line search: argmin f(x + alpha*d)
    obj_alpha = @(a) f(x + a*d);
    alpha = fminbnd(obj_alpha, 0, 10); % Search for alpha >= 0
    
    x_new = x + alpha * d;
    g_new = grad(x_new);
    
    % Fletcher-Reeves Beta
    beta_FR = (g_new' * g_new) / (g' * g);
    
    d = -g_new + beta_FR * d;
    
    x = x_new;
    g = g_new;
    
    fprintf('Iter %d: f(x) = %.6f, Norm(g) = %.6f\n', k, f(x), norm(g));
end