syms x1 x2 x3
f = x1 * x2 * x3;
vars = [x1; x2; x3];

% Given Point and Direction
pt = [1; 1; 1];
d = [1/2; 1/2; 1/sqrt(2)];

% Calculate Gradient
grad_f = gradient(f, vars);

% Evaluate Gradient at the given point
grad_f_at_pt = double(subs(grad_f, vars, pt));

% Directional Derivative (Dot Product)
dir_deriv = dot(grad_f_at_pt, d);

fprintf('Directional Derivative is: %.4f\n', dir_deriv);