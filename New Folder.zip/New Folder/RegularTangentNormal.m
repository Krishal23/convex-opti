syms x1 x2 x3
X = [x1, x2, x3];

% Define the constraints from the Assignment
h1 = x1 + x2 + x3 - 1;
h2 = x1 + x3;
h3 = x1 + x2 - 2;
h = [h1; h2; h3];

X_star = [1, 1, -1];

% --- i) Check for Regular Point ---
J = jacobian(h, X); % Jacobian matrix
J_val = double(subs(J, X, X_star));
r_J = rank(J_val);

fprintf('--- Regular Point Check ---\n');
fprintf('Rank of Jacobian at X* is: %d\n', r_J);
if r_J == length(h)
    fprintf('X* is a regular point (Rank = Number of constraints).\n\n');
else
    fprintf('X* is NOT a regular point.\n\n');
end

% --- ii) Tangent and Normal Space ---
% Normal Space is spanned by the rows of the Jacobian (gradients of h)
fprintf('--- Normal Space ---\n');
disp('Basis vectors of normal space (rows of Jacobian at X*):');
disp(J_val);

% Tangent Space is the null space of the Jacobian
fprintf('--- Tangent Space ---\n');
T_S = null(J_val); 
if isempty(T_S)
    disp('Tangent space is trivial (only the zero vector).');
else
    disp('Basis of Tangent Space:');
    disp(T_S);
end