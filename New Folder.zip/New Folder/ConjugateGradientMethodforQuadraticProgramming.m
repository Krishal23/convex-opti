% Topic 1: Conjugate Gradient Method for QPP
Q = [3, 0, 1; 
     0, 4, 2; 
     1, 2, 3];
b = [3; 0; 1];

x = [0; 0; 0]; % Initial guess x^(0)
g = Q * x - b; % Initial gradient g^(0)
d = -g;        % Initial direction d^(0)

fprintf('--- CG Method for QPP ---\n');
for k = 0:2 % For an nxn matrix, CG converges in exactly n steps
    fprintf('Iteration %d:\n', k);
    disp('x = '); disp(x');
    
    if norm(g) < 1e-6
        fprintf('Converged at iteration %d\n', k);
        break;
    end
    
    % Step 3: Exact line search for quadratic
    alpha = -(g' * d) / (d' * Q * d);
    
    % Step 4: Update x
    x = x + alpha * d;
    
    % Step 5: Update gradient
    g_new = Q * x - b;
    
    % Step 6 & 7: Update beta and direction (using Q-conjugacy formula from board)
    beta = (g_new' * Q * d) / (d' * Q * d);
    d = -g_new + beta * d;
    
    g = g_new; % Set g^(k+1) for next loop
end
fprintf('Final Solution:\n'); disp(x');